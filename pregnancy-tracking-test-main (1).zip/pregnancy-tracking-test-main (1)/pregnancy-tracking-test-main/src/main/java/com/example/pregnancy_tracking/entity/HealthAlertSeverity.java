package com.example.pregnancy_tracking.entity;

public class HealthAlertSeverity {
}
