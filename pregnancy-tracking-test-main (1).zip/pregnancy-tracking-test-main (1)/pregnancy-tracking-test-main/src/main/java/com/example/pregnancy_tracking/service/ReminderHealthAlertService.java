package com.example.pregnancy_tracking.service;

import com.example.pregnancy_tracking.entity.ReminderHealthAlert;
import com.example.pregnancy_tracking.repository.ReminderHealthAlertRepository;
import java.util.Optional;

public class ReminderHealthAlertService {
    private final ReminderHealthAlertRepository reminderHealthAlertRepository;

    public ReminderHealthAlertService(ReminderHealthAlertRepository reminderHealthAlertRepository) {
        this.reminderHealthAlertRepository = reminderHealthAlertRepository;
    }

    public ReminderHealthAlert getReminderHealthAlertById(long id) {
        return reminderHealthAlertRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Reminder Health Alert not found"));
    }

    public ReminderHealthAlert createReminderHealthAlert(ReminderHealthAlert alert) {
        return reminderHealthAlertRepository.save(alert);
    }

    public ReminderHealthAlert updateReminderHealthAlert(long id, ReminderHealthAlert updatedAlert) {
        return reminderHealthAlertRepository.findById(id).map(existingAlert -> {
            existingAlert.setSeverity(updatedAlert.getSeverity());
            existingAlert.setHealthType(updatedAlert.getHealthType());
            existingAlert.setSource(updatedAlert.getSource());
            existingAlert.setNotes(updatedAlert.getNotes());
            return reminderHealthAlertRepository.save(existingAlert);
        }).orElseThrow(() -> new RuntimeException("Reminder Health Alert not found"));
    }

    public void deleteReminderHealthAlert(long id) {
        ReminderHealthAlert alert = reminderHealthAlertRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Reminder Health Alert not found"));
        reminderHealthAlertRepository.delete(alert);
    }
}
