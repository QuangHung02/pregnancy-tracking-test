package com.example.pregnancy_tracking.entity;

public enum PregnancyRecordStatus {
    ACTIVE,
    ISSUE,
    COMPLETED
}
