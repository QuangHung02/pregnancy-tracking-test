package com.example.pregnancy_tracking.service;

public class FetusService {
}
