package com.example.pregnancy_tracking.entity;

public enum ReminderStatus {
    NOT_YET,
    DONE,
    SKIP
}
