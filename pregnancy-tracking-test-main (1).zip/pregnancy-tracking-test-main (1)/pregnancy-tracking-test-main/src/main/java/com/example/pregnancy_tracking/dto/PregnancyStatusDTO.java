package com.example.pregnancy_tracking.dto;

import com.example.pregnancy_tracking.entity.PregnancyStatus;
import lombok.Data;

@Data
public class PregnancyStatusDTO {
    private PregnancyStatus status;
}
