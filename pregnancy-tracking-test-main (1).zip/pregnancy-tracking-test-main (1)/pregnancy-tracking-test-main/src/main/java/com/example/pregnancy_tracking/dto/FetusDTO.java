package com.example.pregnancy_tracking.dto;

public class FetusDTO {
}
