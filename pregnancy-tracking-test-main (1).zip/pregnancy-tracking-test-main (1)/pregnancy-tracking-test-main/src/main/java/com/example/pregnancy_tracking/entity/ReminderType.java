package com.example.pregnancy_tracking.entity;

public enum ReminderType {
    APPOINTMENT,
    MEDICAL_TASK,
    HEALTH_ALERT
}
