package com.example.pregnancy_tracking.entity;

public enum PregnancyStatus {
    ONGOING, COMPLETED, MISCARRIAGE
}
