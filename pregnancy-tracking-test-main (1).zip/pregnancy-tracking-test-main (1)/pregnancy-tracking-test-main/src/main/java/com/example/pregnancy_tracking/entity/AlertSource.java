package com.example.pregnancy_tracking.entity;

public enum AlertSource {
    PREGNANCY_RECORDS,
    MOTHER_RECORDS
}
