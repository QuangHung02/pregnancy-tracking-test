package com.example.pregnancy_tracking.entity;

public enum HealthType {
    LOW_WEIGHT,
    LOW_HEIGHT,
    HIGH_BMI,
    OTHER
}
