package com.example.pregnancy_tracking.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.example.pregnancy_tracking.entity.ReminderHealthAlert;
import com.example.pregnancy_tracking.repository.ReminderHealthAlertRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.util.Optional;

public class ReminderHealthAlertServiceTest {

    @Mock
    private ReminderHealthAlertRepository reminderHealthAlertRepository;

    @InjectMocks
    private ReminderHealthAlertService reminderHealthAlertService;

    private ReminderHealthAlert mockAlert;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockAlert = new ReminderHealthAlert();
        mockAlert.setId(1L);
    }

    @Test
    void testCreateReminderHealthAlert() {
        when(reminderHealthAlertRepository.save(any(ReminderHealthAlert.class))).thenReturn(mockAlert);
        ReminderHealthAlert created = reminderHealthAlertService.createReminderHealthAlert(mockAlert);
        assertNotNull(created);
        assertEquals(1L, created.getId());
    }

    @Test
    void testReadReminderHealthAlert() {
        when(reminderHealthAlertRepository.findById(1L)).thenReturn(Optional.of(mockAlert));
        ReminderHealthAlert found = reminderHealthAlertService.getReminderHealthAlertById(1L);
        assertNotNull(found);
        assertEquals(1L, found.getId());
    }

    @Test
    void testUpdateReminderHealthAlert() {
        when(reminderHealthAlertRepository.findById(1L)).thenReturn(Optional.of(mockAlert));
        when(reminderHealthAlertRepository.save(any(ReminderHealthAlert.class))).thenReturn(mockAlert);
        ReminderHealthAlert updated = reminderHealthAlertService.updateReminderHealthAlert(1L, mockAlert);
        assertNotNull(updated);
        assertEquals(1L, updated.getId());
    }

    @Test
    void testDeleteReminderHealthAlert() {
        when(reminderHealthAlertRepository.findById(1L)).thenReturn(Optional.of(mockAlert));
        doNothing().when(reminderHealthAlertRepository).delete(mockAlert);
        assertDoesNotThrow(() -> reminderHealthAlertService.deleteReminderHealthAlert(1L));
        verify(reminderHealthAlertRepository, times(1)).delete(mockAlert);
    }
}
