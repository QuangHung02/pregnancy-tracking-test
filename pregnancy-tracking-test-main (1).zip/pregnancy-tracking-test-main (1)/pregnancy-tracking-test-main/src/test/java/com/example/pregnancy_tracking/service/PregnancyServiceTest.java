package com.example.pregnancy_tracking.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.example.pregnancy_tracking.dto.PregnancyDTO;
import com.example.pregnancy_tracking.entity.*;
import com.example.pregnancy_tracking.repository.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.List;
import java.util.ArrayList;

public class PregnancyServiceTest {

    @Mock
    private PregnancyRepository pregnancyRepository;
    @Mock
    private UserRepository userRepository;
    @Mock
    private PregnancyRecordRepository pregnancyRecordRepository;
    @Mock
    private FetusRepository fetusRepository;
    @Mock
    private PregnancyRecordService pregnancyRecordService;

    @InjectMocks
    private PregnancyService pregnancyService;

    private Pregnancy mockPregnancy;
    private User mockUser;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockUser = new User();
        mockUser.setId(1L);
        mockUser.setTotalPregnancies(1);
        mockPregnancy = new Pregnancy();
        mockPregnancy.setPregnancyId(1L);
        mockPregnancy.setUser(mockUser);
        mockPregnancy.setStatus(PregnancyStatus.ONGOING);
    }

    @Test
    void testUpdatePregnancyStatus() {
        when(pregnancyRepository.findById(1L)).thenReturn(Optional.of(mockPregnancy));
        when(pregnancyRepository.save(any(Pregnancy.class))).thenReturn(mockPregnancy);

        PregnancyStatus newStatus = PregnancyStatus.COMPLETED;
        Pregnancy updatedPregnancy = pregnancyService.updatePregnancyStatus(1L, newStatus);

        assertNotNull(updatedPregnancy);
        assertEquals(newStatus, updatedPregnancy.getStatus());
        verify(pregnancyRepository, times(1)).save(mockPregnancy);
    }

    @Test
    void testCreatePregnancy() {
        PregnancyDTO dto = new PregnancyDTO();
        dto.setUserId(1L);
        dto.setExamDate(LocalDate.now());
        dto.setGestationalWeeks(10);
        dto.setGestationalDays(3);

        when(userRepository.findById(1L)).thenReturn(Optional.of(mockUser));
        when(pregnancyRepository.save(any(Pregnancy.class))).thenReturn(mockPregnancy);

        Pregnancy createdPregnancy = pregnancyService.createPregnancy(dto);

        assertNotNull(createdPregnancy);
        assertEquals(PregnancyStatus.ONGOING, createdPregnancy.getStatus());
    }
}
