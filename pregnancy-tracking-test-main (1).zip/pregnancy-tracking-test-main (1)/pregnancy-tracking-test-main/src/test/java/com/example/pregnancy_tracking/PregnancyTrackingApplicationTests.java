package com.example.pregnancy_tracking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PregnancyTrackingApplicationTests {
    @Test
    void contextLoads() {
    }
}
